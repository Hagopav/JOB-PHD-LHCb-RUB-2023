```python
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import math

# Data for charmed hadrons
hadrons = {
    "$D_+$": {"composition": "c d\u0304", "lifetime": 1.040e-12},
    "$D_-$": {"composition": "c\u0304 d ", "lifetime": 1.040e-12},
    "$\u039B_{c+}$": {"composition": "c u d", "lifetime": 2.15e-13},
    "$\u039E_{c+}$": {"composition": "c u s", "lifetime": 4.53e-13},
    "$D_{s+}$": {"composition": "c s\u0304", "lifetime": 5.04e-13},
    "$D_{s-}$": {"composition": "s c\u0304", "lifetime": 5.04e-13},
    "$\u03A9_{c0}$": {"composition": "s s c", "lifetime": 2.68e-13},
    "$\u039E_{c0}$": {"composition": "c d s", "lifetime": 1.519e-13},
    "$D_0$": {"composition": "u\u0304 c ", "lifetime": 4.10e-13},
    "$\u039E_{cc++}$": {"composition": "c u c", "lifetime": 2.56e-13}}

x = 1e6  # Scale since lifetimes too small

# Subplots for each charmed hadron
fig, grid = plt.subplots(2, 5, figsize=(15, 6))
grid = grid.ravel() # make a grid

for i, (particle, particle_data) in enumerate(hadrons.items()):
    composition = particle_data["composition"]
    lifetime = particle_data["lifetime"]

    # Calculate the radius of the pie chart scaled by factor x
    radius = np.sqrt(lifetime) * x

    # Get individual quarks
    quarks = composition.split()

    # Count the number of each quark type
    quark_counts = {quark: quarks.count(quark) for quark in quarks}

    # Create a pie chart for each charmed particle
    grid[i].pie(
        quark_counts.values(),
        labels=quark_counts.keys(),
        autopct='%1.1f%%',
        startangle=90,
        radius=radius
    )
    grid[i].set_title(f"{particle}\n Lifetime: {lifetime} s")

# Make things look better by adjusting the spacing between the different pie charts
plt.tight_layout()


```


    
![png](output_0_0.png)
    



```python

```
